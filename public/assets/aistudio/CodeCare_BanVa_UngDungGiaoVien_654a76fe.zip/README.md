# CodeCare – Bản vá giao diện hướng đến giáo viên

## Mục tiêu
- Thanh điều hướng 7 mục nghiệp vụ; Nhật ký, khảo sát và kiểm thử chuyển vào **Công cụ quản trị** dạng thu gọn.
- Không đưa bài luận, nội dung học thuật hoặc trang "AI có trách nhiệm" vào giao diện chính; nguyên tắc quyền giáo viên vẫn ghi ngắn ở sidebar.
- Bỏ tên giảng viên mẫu và số lượng người học cố định; dùng số hồ sơ thực tế từ dữ liệu đang nạp.
- Báo cáo chất lượng cảnh báo hiển thị theo lớp đang chọn; bộ lọc tuần chỉ xuất hiện ở Tổng quan vì các trang khác hiện dùng dữ liệu hồ sơ tổng hợp.
- Cảnh báo chưa xử lý theo lớp đang được chọn; phần đánh giá chất lượng cảnh báo cũng sử dụng đúng nhóm lớp.
- Khi giáo viên lưu lại xác nhận/hồ sơ, giữ tiến độ can thiệp trước đó.

## Áp dụng an toàn vào code MỚI NHẤT trên GitHub
1. Trên GitHub, tải CodeCare bằng nút **Code → Download ZIP** hoặc sử dụng `git clone` trên máy của bạn.
2. Giải nén thư mục `CodeCare`.
3. Từ thư mục chứa file `apply_to_repo.py` chạy:
   ```bash
   python apply_to_repo.py /duong-dan/CodeCare
   ```
   Trên Windows có thể dùng `py apply_to_repo.py "C:\\Users\\...\\CodeCare-main"`.
4. Trước khi tải lên GitHub hoặc xuất bản Vercel, chạy:
   ```bash
   npm install
   npm run lint
   npm run build
   ```
5. Mở web bằng `npm run dev`, kiểm tra các tình huống: chọn lớp, bấm chuông cảnh báo, xác nhận lại một hồ sơ đang can thiệp, chỉnh sửa hồ sơ, mở Công cụ quản trị và chọn xem lịch sử tuần.
6. Chỉ commit 5 file `.tsx` được thay đổi. Các tệp `.before_teacher_ui` là bản sao cục bộ, không cần đẩy lên GitHub.

## Giới hạn hiện tại
CodeCare hiện dùng lưu trữ của trình duyệt (`localStorage`) và chưa có xác thực/đồng bộ giữa nhiều máy. Vì vậy phiên bản này phù hợp demo, thử nghiệm nội bộ bằng dữ liệu giả lập; **không phải** hệ thống quản lý dữ liệu học sinh thật có phân quyền và sao lưu phía máy chủ. Không tự dùng dữ liệu định danh học sinh thật hoặc phát hành công khai mà chưa có cơ chế bảo vệ phù hợp.

## Hoàn tác
Sao chép từng file `App.tsx.before_teacher_ui`, `Header.tsx.before_teacher_ui`, `Sidebar.tsx.before_teacher_ui`, `AuditView.tsx.before_teacher_ui`, `OverviewView.tsx.before_teacher_ui` trở lại tên `.tsx` tương ứng.

## Nếu chỉ sử dụng Google AI Studio
Giải nén gói và tải `ui/Header.tsx`, `ui/Sidebar.tsx`, `apply_to_repo.py` lên làm tài liệu tham chiếu cho bản CodeCare đang mở. Yêu cầu AI Studio:

> Hãy áp dụng có kiểm soát các thay đổi trong `apply_to_repo.py` cho App.tsx, AuditView.tsx và OverviewView.tsx. Thay thế Header.tsx và Sidebar.tsx bằng hai file trong thư mục ui. Không ghi đè mã nguồn nghiệp vụ khác, không thay đổi dữ liệu localStorage. Sau đó kiểm tra build, nút điều hướng, bộ lọc lớp và thao tác xác nhận/duy trì can thiệp. Không tự deploy hoặc xóa dữ liệu.

Đây là bản vá mã nguồn, không phải liên kết cập nhật GitHub tự động. Cần đẩy các thay đổi đã kiểm tra lên repository theo quy trình riêng.

## Kết quả kiểm tra tại thời điểm tạo bản vá
- Đã chạy kiểm tra cú pháp TypeScript/TSX bằng bộ chuyển mã TypeScript: 23 tệp, 0 lỗi cú pháp trên bộ mã thử nghiệm tương thích.
- Đã thực thi tính toán trên bộ 80 hồ sơ trong ZIP tham chiếu: 31 ALERT; ma trận TP=29, FP=2, TN=47, FN=2; bộ kiểm thử: 12 PASS, 0 FAIL, 2 chờ kiểm thử giao diện.
- Chưa xác nhận build của bản GitHub mới nhất vì không thể tải nguyên repository trong môi trường này. Lệnh `npm run lint` trên bộ ZIP tham chiếu không chạy trọn vì thiếu `vite/client` (chưa cài dependencies).
- Phần ứng dụng hiện tại lưu trên trình duyệt, không được tự coi là đã có hệ thống đăng nhập, phân quyền thật hoặc sao lưu máy chủ.
