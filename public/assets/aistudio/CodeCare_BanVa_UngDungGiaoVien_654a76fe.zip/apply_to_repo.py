#!/usr/bin/env python3
"""Safely apply teacher-first CodeCare UI changes to a CURRENT local GitHub checkout.
Usage: python apply_to_repo.py /path/to/CodeCare
No installation, data deletion, deployment or internet access. Keeps all existing business code.
"""
from pathlib import Path
import sys, shutil, re
if len(sys.argv)!=2:
    sys.exit('Cách dùng: python apply_to_repo.py /duong-dan/CodeCare')
repo = Path(sys.argv[1]).expanduser().resolve()
app = repo/'src/App.tsx'
header = repo/'src/components/common/Header.tsx'
sidebar = repo/'src/components/common/Sidebar.tsx'
audit = repo/'src/components/views/AuditView.tsx'
overview = repo/'src/components/views/OverviewView.tsx'
if not all(p.is_file() for p in [app, header, sidebar, audit, overview]):
    sys.exit('Không tìm thấy dự án CodeCare hợp lệ (src/App.tsx, Header.tsx, Sidebar.tsx).')
s = app.read_text(encoding='utf-8')
if "const [currentTab, setCurrentTab]" not in s or "const visibleLearners = useMemo" not in s:
    sys.exit('App.tsx khác cấu trúc dự kiến; không ghi file để tránh mất mã nguồn.')
if 'const classCounts = useMemo' in s:
    sys.exit('Có vẻ bản nâng cấp đã được áp dụng. Không ghi đè lần hai.')
s=s.replace("import { ResponsibleAIView } from './components/views/ResponsibleAIView';\n",'')
s=s.replace('  // Selected learner object for modal', '''  // Dynamic class counts: never assume a fixed number of learners.
  const classCounts = useMemo(() => ({
    LOP_A: allDerivedLearners.filter(l => l.class_name === 'LOP_A').length,
    LOP_B: allDerivedLearners.filter(l => l.class_name === 'LOP_B').length,
    LOP_C: allDerivedLearners.filter(l => l.class_name === 'LOP_C').length,
  }), [allDerivedLearners]);

  // Selected learner object for modal''')
if 'const classCounts = useMemo' not in s:sys.exit('Không nhận diện được chỗ chèn số liệu lớp. Đã dừng an toàn.')
# Only badges for the class currently selected. Never flag learners from other classes.
s=re.sub(r'const unreviewedAlertsCount = useMemo\(\(\) => \{\s*return allDerivedLearners\.filter\(',
         'const unreviewedAlertsCount = useMemo(() => {\n    return visibleLearners.filter(',s)
s=re.sub(r'(const unreviewedAlertsCount = useMemo\(\(\) => \{.*?\n  \}), \[allDerivedLearners\]\);',r'\1, [visibleLearners]);',s, flags=re.S) if False else s
# Replace dependency within the unreviewed block only.
start=s.index('  const unreviewedAlertsCount = useMemo')
end=s.index('  const activeInterventionsCount',start)
block=s[start:end].replace('[allDerivedLearners]', '[visibleLearners]')
s=s[:start]+block+s[end:]
# Update confirmation without wiping progress from an existing intervention.
old='''    const updatedReview = {
      confirmation: decision,
      notes: notes || (reviews[learnerId]?.notes ?? ''),
      intervention_status: decision === 'CONFIRMED' ? 'PENDING' : 'NONE',
      intervention_type: 'Hỗ trợ trực tiếp',
    };'''
new='''    const previous = reviews[learnerId] || {};
    const updatedReview = {
      ...previous,
      confirmation: decision,
      notes: notes?.trim() || previous.notes || '',
      intervention_status: decision === 'CONFIRMED'
        ? (previous.intervention_status && previous.intervention_status !== 'NONE' ? previous.intervention_status : 'PENDING')
        : (previous.intervention_status === 'IN_PROGRESS' ? 'STOPPED' : previous.intervention_status || 'NONE'),
      intervention_type: previous.intervention_type || 'Hỗ trợ trực tiếp',
    };'''
if old not in s:sys.exit('Không nhận diện được hàm xử lý xác nhận cảnh báo; không ghi file.')
s=s.replace(old,new)
old='''    const updatedReview = {
      confirmation: decision,
      notes,
      intervention_type: intervention?.type,
      intervention_status: intervention?.status,
      intervention_date: intervention?.date,
      intervention_outcome: intervention?.outcome,
    };'''
new='''    const previous = reviews[learnerId] || {};
    const updatedReview = {
      ...previous,
      confirmation: decision,
      notes,
      ...(intervention ? {
        intervention_type: intervention.type,
        intervention_status: intervention.status,
        intervention_date: intervention.date,
        intervention_outcome: intervention.outcome,
      } : {}),
    };'''
if old not in s:sys.exit('Không nhận diện được hàm lưu hồ sơ; không ghi file.')
s=s.replace(old,new)
s=s.replace('''        selectedWeek={selectedWeek}
        onWeekChange={setSelectedWeek}''', '''        selectedWeek={selectedWeek}
        onWeekChange={setSelectedWeek}
        showWeekFilter={currentTab === 'overview'}
        classCounts={classCounts}
        totalLearners={allDerivedLearners.length}''')
s=s.replace('''          activeInterventionsCount={activeInterventionsCount}
        />''','''          activeInterventionsCount={activeInterventionsCount}
          totalLearners={allDerivedLearners.length}
        />''')
s=s.replace('''<div className="flex-1 flex overflow-hidden">''','''<div className="flex-1 flex flex-col lg:flex-row min-h-0">''')
s=s.replace('''<main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">''','''<main className="min-w-0 flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">''')
s=s.replace('''              learners={allDerivedLearners}
              thresholds={thresholds}
              onSelectLearner={setSelectedLearnerId}
            />''','''              learners={visibleLearners}
              thresholds={thresholds}
              onSelectLearner={setSelectedLearnerId}
            />''')
s=s.replace("          {currentTab === 'responsible_ai' && <ResponsibleAIView />}\n",'')
if 'showWeekFilter' not in s or 'totalLearners={allDerivedLearners.length}' not in s or 'ResponsibleAIView' in s:
    sys.exit('Không thể kiểm chứng toàn bộ các thay đổi; không ghi file.')
# Align the quality check threshold chart with the chosen class.
audit_text = audit.read_text(encoding='utf-8')
old = '  const rawList = StorageService.getLearnersRaw();'
new = '  const idsInScope = new Set(learners.map(l => l.learner_id));\n  const rawList = StorageService.getLearnersRaw().filter(l => idsInScope.has(l.learner_id));'
if old in audit_text:
    audit_text = audit_text.replace(old, new, 1)
elif new not in audit_text:
    sys.exit('AuditView.tsx có cấu trúc khác; không ghi file.')
audit_text = audit_text.replace('Báo cáo Audit Mô hình & Đánh giá Sư phạm', 'Chất lượng cảnh báo')
audit_text = audit_text.replace('Kiểm định độc lập', 'Đối chiếu dữ liệu mẫu')
audit_text = audit_text.replace('Đánh giá chất lượng của thuật toán suy luận Evidence-based Alert so với nhãn chuẩn chuyên môn của giảng viên (Teacher Ground Truth). Phân tích toàn diện Ma trận nhầm lẫn (Confusion Matrix), Độ chuẩn xác, Độ bao phủ, các trường hợp sai số và tính công bằng giữa các phân nhóm.', 'Giúp giáo viên kiểm tra khi nào hệ thống cảnh báo đúng, khi nào có nguy cơ báo nhầm hoặc bỏ sót. Các số liệu hiện đối chiếu với nhãn tham chiếu trong bộ dữ liệu minh họa.')
audit_text = audit_text.replace('Xuất Báo cáo Audit (JSON)', 'Xuất số liệu kiểm tra (JSON)')
# Remove static demo-only labels and unsupported causal claims from teacher dashboard.
overview_text = overview.read_text(encoding='utf-8')
overview_text = overview_text.replace('Tổng quan Phân tích Học tập & Cảnh báo Sớm', 'Tổng quan lớp học lập trình')
overview_text = overview_text.replace('CodeCare hỗ trợ giáo viên phát hiện sớm các dấu hiệu người học gặp khó khăn trong quá trình học lập trình dựa trên dữ liệu học tập từ LMS và môi trường thực hành. Mọi cảnh báo mang tính gợi ý giải thích được và cần giáo viên xác nhận chuyên môn trước khi can thiệp.', 'Theo dõi bài nộp, kết quả kiểm thử và các dấu hiệu học sinh cần hỗ trợ từ dữ liệu đã nạp vào CodeCare. Giáo viên xem lý do và xác nhận trước khi can thiệp; hệ thống chưa kết nối tự động với LMS.')
overview_text = overview_text.replace('Đã ẩn danh STU001 - STU080', 'Mã định danh trong bộ dữ liệu')
overview_text = overview_text.replace('Dấu hiệu: Người học vượt qua kiểm thử cao hơn ở các bài nhập xuất cơ bản (tuần 1-3).', 'Biểu đồ thể hiện kết quả tổng hợp theo tuần của dữ liệu đang xem; không suy đoán nguyên nhân thay đổi.')
overview_text = overview_text.replace('Tuần 6: ~66%', 'Dữ liệu theo tuần')
overview_text = overview_text.replace('`${Math.round((alertCount / totalLearners) * 100)}% tổng số người học`','`${totalLearners > 0 ? Math.round((alertCount / totalLearners) * 100) : 0}% tổng số người học`')
# Apply only after preflighting every expected transform; keep rest of GitHub checkout unchanged.
for f in [app,header,sidebar,audit,overview]:
    backup = f.with_suffix(f.suffix+'.before_teacher_ui')
    if backup.exists():sys.exit(f'Đã có tệp sao lưu {backup.name}; không ghi đè.')
for f in [app,header,sidebar,audit,overview]:
    shutil.copy2(f,f.with_suffix(f.suffix+'.before_teacher_ui'))
app.write_text(s,encoding='utf-8')
audit.write_text(audit_text,encoding='utf-8')
overview.write_text(overview_text,encoding='utf-8')
for name, target in [('Header.tsx',header),('Sidebar.tsx',sidebar)]:
    target.write_text((Path(__file__).parent/'ui'/name).read_text(encoding='utf-8'),encoding='utf-8')
print('Đã cập nhật 5 file UI theo hướng giáo viên, giữ nguyên logic nghiệp vụ và dữ liệu hiện hành.')
print('Đã tạo các bản sao .before_teacher_ui cạnh từng file.')
print('Tiếp theo: npm install; npm run lint; npm run build. Chưa tự thay đổi repository GitHub từ xa.')
