# Danh mục thay đổi áp dụng lên mã mới nhất

| File | Thay đổi |
|---|---|
| src/components/common/Sidebar.tsx | 7 mục công việc giáo viên, 3 công cụ quản trị có thể thu gọn; bỏ mục học thuật khỏi điều hướng |
| src/components/common/Header.tsx | Không dùng tên giảng viên giả, số lượng lớp/người học động, tuần chỉ xuất hiện trong Tổng quan, hiển thị rõ chế độ demo/lưu cục bộ |
| src/App.tsx | Truyền số lượng thực, đếm cảnh báo theo lớp, sửa luồng cập nhật để không xóa tiến độ can thiệp, truyền nhóm lớp cho Audit, bố cục linh hoạt màn hình nhỏ |
| src/components/views/AuditView.tsx | Đổi nội dung phù hợp người sử dụng là giáo viên; thống nhất mô phỏng ngưỡng với bộ lọc lớp đang chọn |
| src/components/views/OverviewView.tsx | Đổi nội dung giới thiệu ứng dụng, xóa nhãn số lượng STU cố định và nhận định nguyên nhân không có chứng cứ |

**Không chỉnh sửa**: seedData.ts, storage.ts, dataValidator.ts, analytics.ts, testRunner.ts, cấu hình API, khóa lưu trữ cũ hoặc dữ liệu giáo viên trên localStorage. Nhờ đó bản vá không ghi đè các sửa lỗi mới nhất của bản GitHub.
